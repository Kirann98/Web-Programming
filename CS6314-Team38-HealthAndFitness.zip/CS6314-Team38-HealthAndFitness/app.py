from flask import Flask, render_template, request, json, redirect, jsonify
from flask import session
import re
import pymongo
from bson.objectid import ObjectId
from bson import json_util
from flask_debugtoolbar import DebugToolbarExtension

app = Flask(__name__)

app.secret_key = "secret key"

# app.debug = True
# toolbar = DebugToolbarExtension(app)



myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["health_fitness_program"]
userCol = mydb["user"]
historyCol = mydb["history"]
programCol = mydb["program"]
wishCol = mydb["wishlist"]
cartCol = mydb["cart"]


if __name__ == "__main__":
    app.run()


@app.route("/")
def main():
    return render_template("index.html")


@app.route("/showSignIn")
def showSignIn():
    return render_template("signIn.html")


@app.route("/showSignUp")
def showSignUp():
    return render_template("signUp.html")


regex = '^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$'


@app.route("/signUp", methods=['POST'])
def signUp():
    _name = request.form['inputName']
    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    length = len(_password)
    _password = str(length)+","+_password

    # validation of sign up section
    if _name and _email and _password:
        if re.search(regex, _email):
            email = {"email": _email}
            var = userCol.find_one(email)

            # before inserting if the user already exists
            if var == None:
                new = {"email": _email, "password": _password,
                       "name": _name, "isAdmin": 0}
                _id = userCol.insert_one(new)
                return json.dumps({'message': 'user created successfully!!'})

            else:
                return json.dumps({'message': "user Already exists"})

        else:
            return json.dumps({'message': "enter valid email address"})
    else:
        return json.dumps({'html': '<span>enter the required fields</span>'})


@app.route("/signIn", methods=['POST'])
def signIn():
    _email = request.form['inputEmail']
    _password = request.form['inputPassword']
    length = len(_password)
    _password = str(length)+","+_password

    vat = userCol.find_one({"email":_email})
    if vat["password"] == _password:
    # validation of sign up section
        if _email and _password:
            if re.search(regex, _email):
                email = {"email": _email}
                var = userCol.find_one(email)

                # before inserting if the user already exists
                if var != None:
                    # validation
                    if _password == var["password"]:
                        session['user'] = str(var["_id"])
                        if var["isAdmin"] == 0:
                            return redirect('/userHome')
                        else : 
                            return redirect('/adminUserHome')

                else:
                    return json.dumps({'message': "errorrrrr"})

            else:
                return json.dumps({'message': "enter valid email address"})
        else:
            return json.dumps({'html': '<span>enter the required fields</span>'})
    else:
            return json.dumps({'html': '<span>password doesnt match</span>'})


@app.route("/listing", methods=["GET"])
def home():
    test = []
    p = 0
    l = 1
    for doc1 in programCol.find({"status": 1}).skip(p).limit(l):
        doc1["_id"] = str(doc1["_id"])
        test.append(doc1)
    return json.dumps(test)

@app.route("/adminUserHome", methods=["GET"])
def adminUserHome():
    if session.get('user'):
        p = 0
        l = 5
        pri = 0
        d = 0
        if request.args.get("page") is not None:
            p = int(request.args.get("page"))

        if request.args.get("limit") is not None:
            l = int(request.args.get("limit"))

        if request.args.get("price") is not None:
            pri = int(request.args.get("price"))

        if request.args.get("duration") is not None:
            d = int(request.args.get("duration"))

        return render_template("adminHome.html", page = p, limit = l, price = pri, duration = d)
    else:
        return render_template('error.html', error='Unauthorized Access')

@app.route("/listingFilter", methods=["GET"])
def listingFilter():
    test = []
    search = ""
    filterr = ""

    if request.args.get("page") is not None:
        p = int(request.args.get("page"))

    if request.args.get("limit") is not None:
        l = int(request.args.get("limit"))

    if request.args.get("price") is not None:
        pri = int(request.args.get("price"))

    if request.args.get("duration") is not None:
        d = int(request.args.get("duration"))
    
    if request.args.get("search") is not None:        
        search = str(request.args.get("search"))

    if request.args.get("filter") is not None:        
        filterr = str(request.args.get("filter"))
    


    if pri ==0 and d ==0 and search == "" and filterr == "":
        for doc1 in programCol.find({"status": 1}).skip(p).limit(l):
            doc1["_id"] = str(doc1["_id"])
            test.append(doc1)

    if pri !=0 and search == "" and filterr == "" :
        for doc1 in programCol.find({"status": 1}).sort("price",-1).skip(p).limit(l):
            doc1["_id"] = str(doc1["_id"])
            test.append(doc1)

    if d !=0 and search == "" and filterr == "":
        for doc1 in programCol.find({"status": 1}).sort("duration",-1).skip(p).limit(l):
            doc1["_id"] = str(doc1["_id"])
            test.append(doc1)
        
    if search != None and len(search) !=0:
        for doc1 in programCol.find({"status": 1, "name" : search}).skip(p).limit(l):
            doc1["_id"] = str(doc1["_id"])
            test.append(doc1)
    
    if filterr != None and len(filterr) !=0:
        for doc1 in programCol.find({"status": 1, "category" : filterr}).skip(p).limit(l):
            doc1["_id"] = str(doc1["_id"])
            test.append(doc1)

    
    return json.dumps(test)

# @app.route("/userHome")
# def userHome():
#     if session.get('user'):
#         return render_template("userHome.html")
#     else:
#         return render_template('error.html', error='Unauthorized Access')

@app.route("/userHome")
def userHome():
    if session.get('user'):
        p = 0
        l = 5
        pri = 0
        d = 0
        if request.args.get("page") is not None:
            p = int(request.args.get("page"))

        if request.args.get("limit") is not None:
            l = int(request.args.get("limit"))

        if request.args.get("price") is not None:
            pri = int(request.args.get("price"))

        if request.args.get("duration") is not None:
            d = int(request.args.get("duration"))

        return render_template("userHome.html", page = p, limit = l, price = pri, duration = d)
    else:
        return render_template('error.html', error='Unauthorized Access')



@app.route("/addToCart", methods=["GET"])
def cart():
    if session.get('user'):
        user = session.get('user')
        program = request.args.get("programId")
        # check if the user has the product already in cart
        userCart = list(cartCol.find(
            {"program_id": program, "user_id": user, "status": 1}))
        if len(userCart) == 0:
            thisUser = userCol.find_one({"_id": ObjectId(user)})
            thisProgram = programCol.find_one({"_id": ObjectId(program)})
            thisUserId = str(thisUser["_id"])
            thisProgramId = str(thisProgram["_id"])
            doc = {
                "user_id": thisUserId,
                "program_id": thisProgramId,
                "status": 1
            }
            cartCol.insert_one(doc)

            return redirect('/userHome')
        else:
            return "item already exists in cart"
    else:
        return render_template('error.html', error='Unauthorized Access')




@app.route("/deleteCartItem")
def deleteCartItem():
    if session.get('user'):
        user = session.get('user')
        program = request.args.get("programId")
        activeItem = cartCol.find_one(
            {'program_id': program, 'user_id': user, 'status': 1})
        filter = {'_id': activeItem["_id"]}
        newvalues = {"$set": {'status': 0}}
        cartCol.update_one(filter, newvalues)
        return redirect("/showCart")


@app.route("/price", methods=["GET"])
def price():
    user = request.args.get("user_id")
    order = list(cartCol.find({"user_id": user, "status": 1}))
    amount = 0
    for item in order:
        program = item["program_id"]
        programInfo = programCol.find_one({"_id": ObjectId(program)})
        amount += programInfo["price"]
        price = {"price": amount}
    return json.dumps(price)


@app.route("/showCart", methods=["GET"])
def showCart():
    if session.get('user'):
        user = session.get('user')
        return render_template("cart.html", userId=user)
    else:
        return render_template('error.html', error='Unauthorized Access')


@app.route("/getitem", methods=["GET"])
def getitem():
    user = request.args.get("user_id")
    order = list(cartCol.find({"user_id": user, "status": 1}))
    tocart = []
    for item in order:
        program = item["program_id"]
        cartItem = programCol.find_one({"_id": ObjectId(program)})
        cartItem["_id"] = str(cartItem["_id"])
        tocart.append(cartItem)

    return json.dumps(tocart, default=json_util.default)


@app.route("/checkOutItems")
def checkOutItems():
    if session.get('user'):
        user = session.get('user')
        order = list(cartCol.find({"user_id": user, "status": 1}))
        tocart = []
        cartIds = []
        programIds = []
        amount = 0
        for item in order:
            program = item["program_id"]
            cartItem = programCol.find_one({"_id": ObjectId(program)})
            amount += cartItem["price"]
            cartItem["_id"] = str(cartItem["_id"])
            tocart.append(cartItem)
            cartIds.append(str(item["_id"]))
            programIds.append(program)

        response = {"user_id": user, "cartIds": cartIds,
                    "programIds": programIds, "price": amount}
        historyCol.insert_one(response)

        for item in cartIds:
            filter = {'_id': ObjectId(item)}
            newvalues = {"$set": {'status': 0}}
            cartCol.update_one(filter, newvalues)

    return render_template("history.html")

#admin dashboard start    


@app.route("/adminAddItem")
def adminAddItem():
    if session.get('user'):
        return render_template("addItem.html")
    else:
        return render_template('error.html', error='Unauthorized Access')
    


@app.route("/adminDelete", methods=["GET"])
def delete():
    if session.get('user'):
        user = session.get('user')
        var = request.args.get("programId")
        filter = {'_id': ObjectId(var)}
        newvalues = {"$set": {'status': 0}}
        programCol.update_one(filter, newvalues)
        return redirect("/adminUserHome")
    else:
        return render_template('error.html', error='Unauthorized Access')

@app.route("/adminUpdate")
def adminUpdate():
    if session.get('user'):
        user = session.get('user')
        var = request.args.get("programId")
        rec = programCol.find_one({"_id":ObjectId(var)})
        name = rec["name"]
        duration = rec["duration"]
        price = rec["price"]
        description = rec["description"]
        status = rec["status"]
        category = rec["category"]
        image = rec["image"]
        return render_template("edit.html", programName = name, desc = description, duration = duration, cate = category, price = price, image = image, status= status, programId = var)
    else:
        return render_template('error.html', error='Unauthorized Access')





@app.route("/update", methods=["POST"])
def update():
    try:
        if session.get('user'):
            user = session.get('user')
            pId = request.form['inputProgramId']

            var = programCol.find_one({"_id": ObjectId(pId)})

            progname = request.form['inputName']
            description = request.form['inputDescription']
            duration = int(request.form['inputDuration'])
            category = request.form['inputCategory']
            price = int(request.form['inputPrice'])
            status = int(request.form['inputStatus'])
            image= request.form['inputImage']

            filter = {'_id': ObjectId(pId)}
            newvalues = {"$set": {'status': status,
                                'name': progname, 'duration': duration, 'category': category, 'price': price, 'description': description,'image':image}}
            programCol.update_one(filter, newvalues)
            return redirect("/adminUserHome")    
        else:
            return render_template('error.html', error='Unauthorized Access')
    except Exception as e:
        return render_template('error.html', error=str(e))


@app.route('/insertItem', methods=['POST'])
def insertItem():
    progname = request.form['inputName']
    description = request.form['inputDescription']
    duration = int(request.form['inputDuration'])
    category = request.form['inputCategory']
    price = int(request.form['inputPrice'])
    image= request.form['inputImage']

    mydict = { "name": progname, "description": description,"duration":duration, "category":category,"price":price,"status":1,"image":image}
    programCol.insert_one(mydict)

    return redirect('/adminUserHome')

#admin dashboard ends


@app.route("/history")
def getHistory():
    if session.get('user'):
        user = session.get('user')
        history = list(historyCol.find({"user_id": user}))
        programDetails = []
        for order in history:
            programIds = order["programIds"]
            for program in programIds:
                pro = programCol.find_one({"_id": ObjectId(program)})
                proo = {
                    "programName": pro["name"], "price": pro["price"], "image": pro["image"]}
                programDetails.append(proo)
    return json.dumps(programDetails)


@app.route("/historyCheck")
def historyCheck():
    if session.get('user'):
        user = session.get('user')
        return render_template("history.html")
    else:
        return render_template('error.html', error='Unauthorized Access')


@app.route("/logout")
def logout():
    session.pop('user', None)
    return redirect('/')
